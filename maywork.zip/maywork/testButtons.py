import RPi.GPIO as GPIO
import time
import numpy as np
import cv2
import threading

frame = None

def steam():
    cap = cv2.VideoCapture("/dev/video0")
    cap.set(5,30)
    while True:
        global frame 
        ret, frame = cap.read()

but_pin = 18  # Board pin 18


def main():
    # Pin Setup:
    GPIO.setmode(GPIO.BOARD)  # BOARD pin-numbering scheme
    GPIO.setup(40, GPIO.IN)  # button pin set as input
    GPIO.setup(38, GPIO.IN)
    GPIO.setup(37, GPIO.IN)
    GPIO.setup(36, GPIO.IN)
    #x = threading.Thread(target = steam)
    #x.start()
    global frame 
    print("Starting demo now! Press CTRL+C to exit")
    try:
        while True:
                #print("Waiting for button event")            
                #GPIO.wait_for_edge(but_pin, GPIO.FALLING)
                # event received when button pressed
                if(GPIO.input(40)):
                    print("40")
                if(GPIO.input(38)):
                    print("38")
                if(GPIO.input(37)):
                    print("37")
                if(GPIO.input(36)):
                    print("36")
                print()
    #            cv2.imwrite("alpha.jpg", frame)
    #            time.sleep(1)
    finally:
        GPIO.cleanup()  # cleanup all GPIOs

if __name__ == '__main__':
    main()
