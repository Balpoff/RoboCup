from SerialCommand_copy import Com


s = Com(ARDPath = "/dev/ttyUSB0", portSpeed = 115200)


s.writeCmd_(48,49,50, 100)
    
