# robo-football

sudo pip3 install pyserial
camera.py - photapparat
